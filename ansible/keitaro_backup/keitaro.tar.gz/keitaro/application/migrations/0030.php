<?php
use Core\Model\Shard;
use Traffic\Service\SettingsService;
use Services\ShardService;


class Migration_30 extends Migration {

    const DESCRIPTION_RU = 'Добавление device_model и device_type';

    const DESCRIPTION_EN = 'Add device_model and device_type';

    public static function up()
    {
       // removed
    }
}