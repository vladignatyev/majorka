<?php
use Core\Model\Shard;

class Migration_67 extends Migration {

    const DESCRIPTION_RU = 'Изменение структуры таблиц stats (datetime, revenue, cost, stream_id, destination и другие)';

    const DESCRIPTION_EN = 'Update structure of stat tables (datetime, revenue, cost, stream_id, destination и другие)';

    public static function up()
    {
        //deleted
    }
}