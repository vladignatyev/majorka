<?php
class Migration_78 extends Migration {

    const DESCRIPTION_RU = 'Копирование дохода в отчет детализации переходов';

    const DESCRIPTION_EN = 'Copy revenue to detailed reports"';

    public static function up()
    {
        return ; // migration is outdated
    }
}