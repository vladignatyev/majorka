<?php
class Migration_85 extends Migration {

    const DESCRIPTION_RU = 'Перенос данных ips в ip_sessions';

    const DESCRIPTION_EN = 'Copy data from ips to ip_sessions';

    public static function up()
    {
        // removed
    }
}